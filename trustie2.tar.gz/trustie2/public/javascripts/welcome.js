(function () {
	window.onload = function(){
		function fixedBar(id, options){
			var ele = document.getElementById(id);
			if(!ele) return;
			if(/msie (\d+\.\d+)/i.test(navigator.userAgent)){
				var pageHeight=window.innerHeight;
				var d=document;
				if(typeof pageHeight!="number"){
					if(document.compatMode=="CSS1Compat"){
						pageHeight=document.documentElement.clientHeight;
					}else{
						pageHeight=document.body.clientHeight;
					}
				}
				var ieScrollTop=window.pageYOffset || d.documentElement.scrollTop || d.body.scrollTop;
				if(options.addclass) ele.className = options.addclass;
				ele.style.position= 'absolute';

				if(options.show){
					ele.style.top = 0 + "px";
					ele.style.display= 'block';
				}

				window.attachEvent('onscroll' , function (){

					var ieScrollTop=window.pageYOffset || d.documentElement.scrollTop || d.body.scrollTop;

					ele.style.top = 0 + "px";
					if(options.autoHidden){
						if(ieScrollTop==0){
							ele.style.display="none";
						}else{
							ele.style.display="block";
						}
					}
				});
			}else{
				var ele = document.getElementById(id);
				if(typeof pageHeight!="number"){
					if(document.compatMode=="CSS1Compat"){
						pageHeight=document.documentElement.clientHeight;
					}else{
						pageHeight=document.body.clientHeight;
					}
				}
				if(options.show) ele.style.display= 'block';
				ele.style.top = 0 +'px';
				window.addEventListener('scroll',function (){
					if(options.autoHidden){
						if(baidu.page.getScrollTop()==0){
							ele.style.display="none";
						}else{
							ele.style.display="block";
						}
					}
				},false);
			}
		}

		fixedBar('backTopBtn' , {autoHidden: true, top : 186});
		fixedBar('identifier-pannel' , {autoHidden: false , top : 956 , show : true});
	}
})();