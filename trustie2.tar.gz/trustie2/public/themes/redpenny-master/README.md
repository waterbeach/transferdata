## Red Penny - Redmine Theme.

### Installation
To install, just clone Red Penny files to your Redmine theme directory "public/themes"

zsh$ cd /path/to/redmine/public/themes

zsh$ git clone http://github.com/themondays/redpenny.git redpenny

### Additional thank for amazing fonts:
Dave Gandy (@byscuits)
Paul D. Hunt