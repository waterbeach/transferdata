require 'test_helper'

class TestControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
  test "get test index error" do
  	@request.env["REQUEST_URI"] = ""
  	get :index
  	assert_template :index
  	# assert_template layout: "layouts/base", partial: ["layouts/base_header","_base_header", 'layouts/base_footer', "_base_footer",]
  end
end
