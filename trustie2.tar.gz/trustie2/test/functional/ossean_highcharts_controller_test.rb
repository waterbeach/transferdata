require 'test_helper'

class OsseanHighchartsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
