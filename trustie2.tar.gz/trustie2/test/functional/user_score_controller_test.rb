require 'test_helper'

class UserScoreControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
