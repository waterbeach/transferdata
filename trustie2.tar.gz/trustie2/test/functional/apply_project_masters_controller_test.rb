require 'test_helper'

class ApplyProjectMastersControllerTest < ActionController::TestCase
  setup do
    @apply_project_master = apply_project_masters(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:apply_project_masters)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create apply_project_master" do
    assert_difference('ApplyProjectMaster.count') do
      post :create, apply_project_master: {  }
    end

    assert_redirected_to apply_project_master_path(assigns(:apply_project_master))
  end

  test "should show apply_project_master" do
    get :show, id: @apply_project_master
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @apply_project_master
    assert_response :success
  end

  test "should update apply_project_master" do
    put :update, id: @apply_project_master, apply_project_master: {  }
    assert_redirected_to apply_project_master_path(assigns(:apply_project_master))
  end

  test "should destroy apply_project_master" do
    assert_difference('ApplyProjectMaster.count', -1) do
      delete :destroy, id: @apply_project_master
    end

    assert_redirected_to apply_project_masters_path
  end
end
