require 'test_helper'

class SoftapplicationsControllerTest < ActionController::TestCase
  setup do
    @softapplication = softapplications(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:softapplications)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create softapplication" do
    assert_difference('Softapplication.count') do
      post :create, softapplication: { android_min_version_available: @softapplication.android_min_version_available, app_type_id: @softapplication.app_type_id, app_type_name: @softapplication.app_type_name, description: @softapplication.description, name: @softapplication.name, user_id: @softapplication.user_id }
    end

    assert_redirected_to softapplication_path(assigns(:softapplication))
  end

  test "should show softapplication" do
    get :show, id: @softapplication
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @softapplication
    assert_response :success
  end

  test "should update softapplication" do
    put :update, id: @softapplication, softapplication: { android_min_version_available: @softapplication.android_min_version_available, app_type_id: @softapplication.app_type_id, app_type_name: @softapplication.app_type_name, description: @softapplication.description, name: @softapplication.name, user_id: @softapplication.user_id }
    assert_redirected_to softapplication_path(assigns(:softapplication))
  end

  test "should destroy softapplication" do
    assert_difference('Softapplication.count', -1) do
      delete :destroy, id: @softapplication
    end

    assert_redirected_to softapplications_path
  end
end
