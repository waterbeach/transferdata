require 'test_helper'

class UsersControllerTest < ActionController::TestCase
  fixtures :users, :user_extensions
  def setup
  	initial_user_controller
  end
  def teardown
  	teardown_user_controller
  end

  test "test user valid" do
  	assert @user.valid?, "user valid."
  end

  test "get user_courses page" do
  	get :user_courses, {:id => @user.id}
  	assert_response :success
  end

  private

  def initial_user_controller
  	@user = users(:person_mao)
    @user_yan = users(:person_one)
  end

  def teardown_user_controller
  	@user = nil
    @user_yan = nil
  end
end
