require 'test_helper'

class ZipdownControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
