require 'test_helper'

class MemosControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
  def test_memo_create_fail
  	memo = Memo.create(:title => nil)
  	assert true
  end
end
