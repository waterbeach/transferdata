require 'test_helper'

class UserTracesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
