# encoding: utf-8
require 'test_helper'

class MemoTest < ActiveSupport::TestCase
  test "the truth" do
    assert true
  end

  def test_the_truth
  	assert true
  end

  test "should not save memo without content" do
  	memo = Memo.new
  	assert !memo.save, "assert, save memo without content."
  end
end
