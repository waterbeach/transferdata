require 'test_helper'

class NoUseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
