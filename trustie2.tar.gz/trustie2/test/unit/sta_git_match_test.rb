require 'test_helper'

class StaGitMatchTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
