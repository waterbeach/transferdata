# encoding: utf-8
# Redmine - project management software
# Copyright (C) 2006-2013  Jean-Philippe Lang
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

require File.expand_path('../../test_helper', __FILE__)

class CourseTest < ActiveSupport::TestCase
  def setup
  	@course_1 = Course.new
  	@course_1.id = 1
  	@course_1.tea_id = 1
  	@course_1.name = 'course1'
  	@course_1.state = 1234
  	@course_1.time = 2012
  	@course_1.term = '秋季学期'
  	@course_1.password = 1234
  	@course_1.class_period = 40

  	@course_2 = Course.new
  	@course_2.id = 2
  	@course_2.tea_id = 1
  	@course_2.name = 'course2'
  	@course_2.state = 1234
  	@course_2.time = 2013
  	@course_2.term = '秋季学期'
  	@course_2.password = 1234
  	@course_2.class_period = 40

  	@course_3 = Course.new
  	@course_3.id = 3
  	@course_3.tea_id = 1
  	@course_3.name = 'course3'
  	@course_3.state = 1234
  	@course_3.time = 2014
  	@course_3.term = '秋季学期'
  	@course_3.password = 1234
  	@course_3.class_period = 40

  	@course_now = Course.new
  	@course_now.id = 4
  	@course_now.tea_id = 1
  	@course_now.name = 'course4'
  	@course_now.state = 1234
  	@course_now.time = 2013
  	@course_now.term = '秋季学期'
  	@course_now.password = 1234
  	@course_now.class_period = 40
  end
  	
  test 'test course whether out of date.' do
  	true
  end

  def teardown
  end
end
