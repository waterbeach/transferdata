require 'test_helper'

class JournalReplyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
