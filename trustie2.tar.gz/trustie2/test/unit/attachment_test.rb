# encoding: utf-8
require 'test_helper'

class AttachmentsTest < ActiveSupport::TestCase
  include AttachmentsHelper

  def setup
    @file_belong_to = attachments(:attachments_021)
    @file_not_belong_to = attachments(:attachments_022)
    @project = @file_belong_to.container
  end

  test "can be find file not belong to project" do
    params = {:q => @file_not_belong_to}
    found_file = render_attachments_for_new_project(@project)
    assert found_file.include?(@file_not_belong_to)
    assert_not found_file.include?(@file_belong_to)
  end

end
