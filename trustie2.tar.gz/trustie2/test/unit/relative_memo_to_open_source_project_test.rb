require 'test_helper'

class RelativeMemoToOpenSourceProjectTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
