require 'test_helper'

class AttachmentstypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
