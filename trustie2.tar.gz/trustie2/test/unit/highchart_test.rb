require 'test_helper'

class HighchartTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
