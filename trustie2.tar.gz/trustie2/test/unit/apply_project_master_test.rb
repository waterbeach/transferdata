require 'test_helper'

class ApplyProjectMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
