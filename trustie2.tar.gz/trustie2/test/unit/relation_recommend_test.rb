require 'test_helper'

class RelationRecommendTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
