require 'test_helper'

class SimilityRecommendTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
