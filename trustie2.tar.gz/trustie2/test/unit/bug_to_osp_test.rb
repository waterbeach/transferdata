require 'test_helper'

class BugToOspTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
