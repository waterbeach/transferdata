require 'test_helper'

class StackoverflowUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
