require 'test_helper'

class OpenSourceProjectInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
