require 'test_helper'

class JoinInContestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
