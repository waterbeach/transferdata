require 'test_helper'

class OsseanStaGitMatchsHelperTest < ActionView::TestCase
end
