require 'test_helper'

class ZipdownHelperTest < ActionView::TestCase
end
