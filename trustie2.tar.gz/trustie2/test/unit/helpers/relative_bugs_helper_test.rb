require 'test_helper'

class RelativeBugsHelperTest < ActionView::TestCase
end
