require 'test_helper'

class SchoolHelperTest < ActionView::TestCase
end
