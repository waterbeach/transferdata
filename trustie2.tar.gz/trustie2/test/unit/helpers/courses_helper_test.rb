require File.expand_path('../../../test_helper', __FILE__)

class CoursesHelperTest < ActionView::TestCase
	include CoursesHelper
	# test "test truth" do
	# 	@project = Project.find_by_id 6834
	# 	teacherNum = teacherCount @project
	# 	studentNum = studentCount @project
	# 	assert_equal 1, teacherNum
	# 	assert_equal 5, studentNum
	# end
end
