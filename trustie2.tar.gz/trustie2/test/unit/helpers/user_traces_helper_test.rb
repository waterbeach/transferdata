require 'test_helper'

class UserTracesHelperTest < ActionView::TestCase
end
