require 'test_helper'

class OsseanHighchartsHelperTest < ActionView::TestCase
end
