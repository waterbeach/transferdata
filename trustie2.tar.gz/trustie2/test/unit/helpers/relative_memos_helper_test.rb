require 'test_helper'

class RelativeMemosHelperTest < ActionView::TestCase
end
