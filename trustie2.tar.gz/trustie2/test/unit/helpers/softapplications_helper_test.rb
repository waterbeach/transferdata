require 'test_helper'

class SoftapplicationsHelperTest < ActionView::TestCase
end
