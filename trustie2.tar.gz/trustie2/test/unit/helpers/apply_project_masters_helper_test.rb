require 'test_helper'

class ApplyProjectMastersHelperTest < ActionView::TestCase
end
