require 'test_helper'

class NoUsesHelperTest < ActionView::TestCase
end
