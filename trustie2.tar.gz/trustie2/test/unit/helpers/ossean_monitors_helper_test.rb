require 'test_helper'

class OsseanMonitorsHelperTest < ActionView::TestCase
end
