require 'test_helper'

class OpenSourceProjectsHelperTest < ActionView::TestCase
end
